# User Interface to interact with the Local RAG Model
# Created: 2024-10-29
# By: Jacky Luong

import tkinter
import customtkinter
from query_data import query_rag

# Array of all textboxes
text_boxes = []

# Font size factor when the app window is resized
font_size_factor = 20

# Function to dynamically adjust font size based on window size
#
# Params
# Event event Default(None)
def update_font_size(event=None):
    # Calculate a new font size based on window width
    new_font_size = max(10, int(app.winfo_width() / font_size_factor))
    message.configure(font=("Arial", new_font_size))

    # Update new font size on all text boxes
    for text_box in text_boxes:
        text_box.configure(font=("Arial", new_font_size))

# Funciton to adjust the height of the textbox based on the number of line breaks
#
# Params
# CTkTextbox text_box
def adjust_textbox_height(text_box):
    # Get the current text and split into lines
    text_lines = text_box.get("1.0", "end-1c").split('\n')
    line_count = len(text_lines)

    # Calculate the required height
    line_height = font_size_factor  # Adjust based on your font size (in pixels)
    required_height = line_count * line_height

    # Update the height of the textbox
    text_box.configure(height=required_height)

# Funciton calls query_data.query_rag() and generates a display for the user's input and the ai's input
#
# Params
# string question
# CTkTextbox question_text_box
# CTkFrame response_frame
def query_rag_gui(question, question_text_box, response_frame):
    response_text = query_rag(question)

    # User response
    user_frame = customtkinter.CTkFrame(response_frame)
    user_frame.pack(fill="x", expand=True, pady=10, padx=10)

    user_text_box = customtkinter.CTkTextbox(user_frame, width=400, height=100, wrap=tkinter.WORD)
    user_text_box.insert("0.0", question)
    user_text_box.configure(state="disabled")  # Disable the text box to make it read-only
    # Adjust_textbox_height(user_text_box)
    user_text_box.pack(side="right", pady=10)

    # AI response
    ai_frame = customtkinter.CTkFrame(response_frame)
    ai_frame.pack(fill="both", expand=True, pady=10, padx=10)

    ai_text_box = customtkinter.CTkTextbox(ai_frame, width=400, height=300, wrap=tkinter.WORD)
    ai_text_box.insert("0.0", response_text)
    ai_text_box.configure(state="disabled")  # Disable the text box to make it read-only
    # adjust_textbox_height(ai_text_box)
    ai_text_box.pack(side="left", fill="x", expand=True, pady=10, padx=(0,200))

    # Clear the textbox
    question_text_box.delete(0, customtkinter.END)

    # Add generated textboxs to the textbox array
    text_boxes.append(user_text_box)
    text_boxes.append(ai_text_box)
    
    # Update fonts for textboxes
    update_font_size()


# App Frame
app=customtkinter.CTk()
app.geometry("720x480")
app.minsize(720, 480)
app.title("Local RAG Model")

# Bind the function to window resizing
app.bind("<Configure>", update_font_size)

# Response frame
response_frame = customtkinter.CTkScrollableFrame(app, width=450, height=200)
response_frame.pack(fill="both", expand=True, padx=10, pady=10)

# Input frame
input_frame = customtkinter.CTkFrame(app)
input_frame.pack(side="bottom", fill="both", expand=True, padx=10, pady=10)

# User question box
message = customtkinter.CTkEntry(input_frame, width=350, height=40)
message.configure(bg_color="transparent", border_width=0) 
message.pack(side="left", fill="both", expand=True, padx=(0,5))

# Send button
submit_button = customtkinter.CTkButton(input_frame, text="Send", command=lambda: query_rag_gui(message.get(), message, response_frame))
submit_button.pack(side="right", padx=(5,0)) 

app.mainloop()